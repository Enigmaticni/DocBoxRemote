import { useAuth } from "@/_core/hooks/useAuth";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Send, 
  Phone, 
  Monitor, 
  Settings, 
  LogOut, 
  Moon, 
  Sun,
  Users,
  MessageSquare,
  Bell,
  Upload,
  Zap
} from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [activeTab, setActiveTab] = useState<'chat' | 'contacts' | 'calls' | 'settings'>('chat');
  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [selectedContact, setSelectedContact] = useState<any>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: contacts } = trpc.contacts.list.useQuery(undefined, { enabled: isAuthenticated });
  const { data: notifications } = trpc.notifications.list.useQuery({ limit: 20 }, { enabled: isAuthenticated });
  const sendMessageMutation = trpc.messages.send.useMutation();
  const updateStatusMutation = trpc.user.updateStatus.useMutation();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !selectedContact) return;
    
    try {
      await sendMessageMutation.mutateAsync({
        receiverId: selectedContact.id,
        content: inputMessage
      });
      setMessages([...messages, { 
        id: Date.now(), 
        content: inputMessage, 
        senderId: user?.id, 
        timestamp: new Date() 
      }]);
      setInputMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity }}>
          <Zap className="w-12 h-12 text-blue-500" />
        </motion.div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-md"
        >
          <div className="mb-8">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block"
            >
              <Monitor className="w-16 h-16 text-blue-500 mx-auto mb-4" />
            </motion.div>
            <h1 className="text-4xl font-bold text-white mb-2">DocBox Remote</h1>
            <p className="text-gray-300 mb-8">Real-time screen sharing & communication platform</p>
          </div>
          
          <Button 
            onClick={() => window.location.href = getLoginUrl()}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-all"
          >
            Sign in with Manus
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      {/* Header */}
      <motion.header 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className={`${theme === 'dark' ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border-b sticky top-0 z-50`}
      >
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Monitor className="w-8 h-8 text-blue-500" />
            <h1 className="text-2xl font-bold">DocBox Remote</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 hover:bg-opacity-10 hover:bg-white rounded-lg transition"
            >
              <Bell className="w-6 h-6" />
              {notifications && notifications.filter(n => !n.read).length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              )}
            </button>
            
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-opacity-10 hover:bg-white rounded-lg transition"
            >
              {theme === 'dark' ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
            </button>
            
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold">
              {user?.name?.charAt(0) || 'U'}
            </div>
            
            <button
              onClick={() => logout()}
              className="p-2 hover:bg-opacity-10 hover:bg-white rounded-lg transition"
            >
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto flex gap-4 p-4">
        {/* Sidebar */}
        <motion.aside 
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className={`w-64 ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'} rounded-lg p-4 h-[calc(100vh-100px)]`}
        >
          <div className="space-y-2 mb-6">
            {[
              { id: 'chat', label: 'Messages', icon: MessageSquare },
              { id: 'contacts', label: 'Contacts', icon: Users },
              { id: 'calls', label: 'Calls', icon: Phone },
              { id: 'settings', label: 'Settings', icon: Settings }
            ].map(({ id, label, icon: Icon }) => (
              <motion.button
                key={id}
                whileHover={{ x: 4 }}
                onClick={() => setActiveTab(id as any)}
                className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition ${
                  activeTab === id
                    ? 'bg-blue-600 text-white'
                    : theme === 'dark' ? 'hover:bg-slate-700' : 'hover:bg-slate-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{label}</span>
              </motion.button>
            ))}
          </div>

          {/* Contacts List */}
          {activeTab === 'contacts' && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-2"
            >
              <h3 className="font-semibold text-sm text-gray-500 mb-3">Your Contacts</h3>
              {contacts?.map((contact) => (
                <motion.button
                  key={contact.id}
                  whileHover={{ x: 4 }}
                  onClick={() => setSelectedContact(contact)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition ${
                    selectedContact?.id === contact.id
                      ? 'bg-blue-600 text-white'
                      : theme === 'dark' ? 'hover:bg-slate-700' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${contact.status === 'online' ? 'bg-green-500' : 'bg-gray-500'}`} />
                    <span className="text-sm">{contact.name}</span>
                  </div>
                </motion.button>
              ))}
            </motion.div>
          )}
        </motion.aside>

        {/* Main Chat Area */}
        <motion.main 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className={`flex-1 ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'} rounded-lg p-6 flex flex-col h-[calc(100vh-100px)]`}
        >
          {activeTab === 'chat' && selectedContact ? (
            <>
              {/* Chat Header */}
              <div className="flex items-center justify-between mb-4 pb-4 border-b border-slate-700">
                <div>
                  <h2 className="text-xl font-bold">{selectedContact.name}</h2>
                  <p className="text-sm text-gray-500">{selectedContact.status}</p>
                </div>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
                  >
                    <Phone className="w-5 h-5" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition"
                  >
                    <Monitor className="w-5 h-5" />
                  </motion.button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto mb-4 space-y-3">
                {messages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg ${
                        msg.senderId === user?.id
                          ? 'bg-blue-600 text-white'
                          : theme === 'dark' ? 'bg-slate-700' : 'bg-slate-100'
                      }`}
                    >
                      <p>{msg.content}</p>
                      <p className="text-xs mt-1 opacity-70">
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="flex gap-2">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type a message..."
                  className={`flex-1 ${theme === 'dark' ? 'bg-slate-700 border-slate-600' : 'bg-slate-100'}`}
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleSendMessage}
                  disabled={sendMessageMutation.isPending}
                  className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                </motion.button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <MessageSquare className="w-16 h-16 mb-4 opacity-50" />
              <p>Select a contact to start chatting</p>
            </div>
          )}
        </motion.main>
      </div>
    </div>
  );
}
