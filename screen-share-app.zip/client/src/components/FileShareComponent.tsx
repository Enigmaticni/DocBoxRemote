import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, Download, File, X, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { trpc } from '@/lib/trpc';

interface FileShareComponentProps {
  contactId: number;
  onClose: () => void;
}

export default function FileShareComponent({ contactId, onClose }: FileShareComponentProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadStartMutation = trpc.files.uploadStart.useMutation();
  const uploadCompleteMutation = trpc.files.uploadComplete.useMutation();
  const shareMutation = trpc.files.share.useMutation();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleUpload = async () => {
    for (const file of files) {
      try {
        setUploadProgress(prev => ({ ...prev, [file.name]: 0 }));

        // Start upload
        const uploadStart = await uploadStartMutation.mutateAsync({
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type
        });

        // Simulate file upload with progress
        const formData = new FormData();
        formData.append('file', file);

        // In real app, upload to S3 using presigned URL
        const uploadedFile = await uploadCompleteMutation.mutateAsync({
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
          s3Key: uploadStart.s3Key,
          s3Url: `https://s3.example.com/${uploadStart.s3Key}`
        });

        setUploadedFiles(prev => [...prev, uploadedFile]);
        setUploadProgress(prev => ({ ...prev, [file.name]: 100 }));
      } catch (error) {
        console.error('Upload error:', error);
      }
    }
  };

  const handleShare = async () => {
    if (uploadedFiles.length === 0) return;

    try {
      for (const file of uploadedFiles) {
        await shareMutation.mutateAsync({
          fileId: file.fileId,
          sharedWithIds: [contactId]
        });
      }
      // Reset after sharing
      setFiles([]);
      setUploadedFiles([]);
      setUploadProgress({});
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="bg-white dark:bg-slate-800 rounded-lg p-6 max-w-md w-full"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Share Files</h3>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-200 dark:hover:bg-slate-700 rounded transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* File Input Area */}
      <div
        onClick={() => fileInputRef.current?.click()}
        className="border-2 border-dashed border-blue-300 rounded-lg p-6 text-center cursor-pointer hover:bg-blue-50 dark:hover:bg-slate-700 transition mb-4"
      >
        <Upload className="w-8 h-8 text-blue-500 mx-auto mb-2" />
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Click to select files or drag and drop
        </p>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>

      {/* Selected Files */}
      {files.length > 0 && (
        <div className="mb-4 space-y-2">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            Selected Files ({files.length})
          </h4>
          {files.map((file, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 p-2 bg-gray-100 dark:bg-slate-700 rounded"
            >
              <File className="w-4 h-4 text-gray-500" />
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{file.name}</p>
                <p className="text-xs text-gray-500">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Upload Progress */}
      {Object.keys(uploadProgress).length > 0 && (
        <div className="mb-4 space-y-2">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
            Upload Progress
          </h4>
          {Object.entries(uploadProgress).map(([fileName, progress]) => (
            <div key={fileName}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs truncate">{fileName}</span>
                <span className="text-xs text-gray-500">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          ))}
        </div>
      )}

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <div className="mb-4 space-y-2">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            Ready to Share
          </h4>
          {uploadedFiles.map((file, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 p-2 bg-green-50 dark:bg-slate-700 rounded"
            >
              <CheckCircle className="w-4 h-4 text-green-500" />
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{file.fileName}</p>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        {files.length > 0 && uploadedFiles.length === 0 && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleUpload}
            disabled={uploadStartMutation.isPending}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition disabled:opacity-50"
          >
            {uploadStartMutation.isPending ? 'Uploading...' : 'Upload'}
          </motion.button>
        )}

        {uploadedFiles.length > 0 && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleShare}
            disabled={shareMutation.isPending}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition disabled:opacity-50"
          >
            {shareMutation.isPending ? 'Sharing...' : 'Share Files'}
          </motion.button>
        )}

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onClose}
          className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 rounded-lg transition"
        >
          Close
        </motion.button>
      </div>
    </motion.div>
  );
}
