import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { 
  addContact, 
  getContacts, 
  saveMessage, 
  getMessages, 
  saveFile, 
  getFile,
  createConnection,
  getConnection,
  createNotification,
  getNotifications,
  markNotificationAsRead,
  getDb
} from "./db";
import { users, connections } from "../drizzle/schema";
import { eq } from "drizzle-orm";
import { storageGet } from "./storage";
import { invokeLLM } from "./_core/llm";
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
    
    setupTwoFactor: protectedProcedure.mutation(async ({ ctx }) => {
      const secret = speakeasy.generateSecret({
        name: `DocBox Remote (${ctx.user.email})`,
        issuer: 'DocBox Remote',
        length: 32
      });
      const qrCode = await QRCode.toDataURL(secret.otpauth_url!);
      return { secret: secret.base32, qrCode };
    }),
    
    verifyTwoFactor: protectedProcedure
      .input(z.object({ secret: z.string(), token: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const isValid = speakeasy.totp.verify({
          secret: input.secret,
          encoding: 'base32',
          token: input.token,
          window: 2
        });
        if (!isValid) throw new Error('Invalid 2FA token');
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        await db.update(users)
          .set({ twoFactorEnabled: true, twoFactorSecret: input.secret })
          .where(eq(users.id, ctx.user.id));
        return { success: true };
      }),
    
    disableTwoFactor: protectedProcedure.mutation(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      await db.update(users)
        .set({ twoFactorEnabled: false, twoFactorSecret: null })
        .where(eq(users.id, ctx.user.id));
      return { success: true };
    }),
  }),
  
  user: router({
    updateStatus: protectedProcedure
      .input(z.enum(['online', 'away', 'busy', 'offline']))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        await db.update(users).set({ status: input }).where(eq(users.id, ctx.user.id));
        return { success: true };
      }),
    
    updateProfile: protectedProcedure
      .input(z.object({ name: z.string().optional(), avatar: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        await db.update(users).set({ name: input.name, avatar: input.avatar }).where(eq(users.id, ctx.user.id));
        return { success: true };
      }),
  }),
  
  contacts: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const contactIds = await getContacts(ctx.user.id);
      const db = await getDb();
      if (!db) throw new Error('Database not available');
      const contactList = await Promise.all(
        contactIds.map(async (c) => {
          const result = await db.select().from(users).where(eq(users.id, c.contactId)).limit(1);
          return result[0];
        })
      );
      return contactList.filter(Boolean);
    }),
    
    add: protectedProcedure
      .input(z.object({ contactId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await addContact(ctx.user.id, input.contactId);
        return { success: true };
      }),
  }),
  
  messages: router({
    list: protectedProcedure
      .input(z.object({ contactId: z.number(), limit: z.number().default(50) }))
      .query(async ({ ctx, input }) => {
        return getMessages(ctx.user.id, input.contactId, input.limit);
      }),
    
    send: protectedProcedure
      .input(z.object({ receiverId: z.number(), content: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await saveMessage(ctx.user.id, input.receiverId, input.content, 'text');
        await createNotification(
          input.receiverId,
          'message',
          `New message from ${ctx.user.name || 'Unknown'}`,
          input.content.substring(0, 100),
          ctx.user.id
        );
        return { success: true };
      }),
    
    aiChat: protectedProcedure
      .input(z.object({ message: z.string(), context: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          messages: [
            { 
              role: 'system', 
              content: `You are a helpful AI assistant for a screen sharing and video communication platform. You help users with technical questions and troubleshooting. ${input.context ? `Context: ${input.context}` : ''}` 
            },
            { role: 'user', content: input.message }
          ]
        });
        const aiMessage = typeof response.choices[0]?.message.content === 'string' ? response.choices[0].message.content : '';
        await saveMessage(ctx.user.id, ctx.user.id, aiMessage, 'ai');
        return { response: aiMessage };
      }),
  }),
  
  files: router({
    uploadStart: protectedProcedure
      .input(z.object({ fileName: z.string(), fileSize: z.number(), mimeType: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const s3Key = `files/${ctx.user.id}/${Date.now()}-${input.fileName}`;
        return {
          s3Key,
          uploadUrl: `${process.env.VITE_FRONTEND_FORGE_API_URL}/upload`,
        };
      }),
    
    uploadComplete: protectedProcedure
      .input(z.object({ fileName: z.string(), fileSize: z.number(), mimeType: z.string(), s3Key: z.string(), s3Url: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await saveFile(
          ctx.user.id,
          input.fileName,
          input.fileSize,
          input.mimeType,
          input.s3Key,
          input.s3Url
        );
        return { success: true };
      }),
    
    share: protectedProcedure
      .input(z.object({ fileId: z.number(), sharedWithIds: z.array(z.number()) }))
      .mutation(async ({ ctx, input }) => {
        const file = await getFile(input.fileId);
        if (!file) throw new Error('File not found');
        for (const userId of input.sharedWithIds) {
          await createNotification(
            userId,
            'file_share',
            `${ctx.user.name || 'Someone'} shared a file with you`,
            file.fileName,
            ctx.user.id
          );
        }
        return { success: true };
      }),
    
    download: protectedProcedure
      .input(z.object({ fileId: z.number() }))
      .query(async ({ ctx, input }) => {
        const file = await getFile(input.fileId);
        if (!file) throw new Error('File not found');
        const downloadUrl = await storageGet(file.s3Key);
        return downloadUrl;
      }),
  }),
  
  connectionRouter: router({
    request: protectedProcedure
      .input(z.object({ receiverId: z.number(), type: z.enum(['chat', 'screen_share', 'video_call']) }))
      .mutation(async ({ ctx, input }) => {
        await createConnection(ctx.user.id, input.receiverId, input.type);
        const typeLabel = input.type === 'screen_share' ? 'Screen Share' : input.type === 'video_call' ? 'Video Call' : 'Chat';
        await createNotification(
          input.receiverId,
          'connection_request',
          `${ctx.user.name || 'Someone'} wants to ${typeLabel.toLowerCase()}`,
          `${typeLabel} request from ${ctx.user.name || 'Unknown'}`,
          ctx.user.id
        );
        return { success: true };
      }),
    
    respond: protectedProcedure
      .input(z.object({ connectionId: z.number(), accepted: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        const connection = await getConnection(input.connectionId);
        if (!connection) throw new Error('Connection not found');
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        if (input.accepted) {
          await db.update(connections)
            .set({ status: 'active', startedAt: new Date() })
            .where(eq(connections.id, input.connectionId));
        } else {
          await db.update(connections)
            .set({ status: 'rejected' })
            .where(eq(connections.id, input.connectionId));
        }
        return { success: true };
      }),
    
    end: protectedProcedure
      .input(z.object({ connectionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error('Database not available');
        await db.update(connections)
          .set({ status: 'ended', endedAt: new Date() })
          .where(eq(connections.id, input.connectionId));
        return { success: true };
      }),
  }),
  
  notifications: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(20) }))
      .query(async ({ ctx, input }) => {
        return getNotifications(ctx.user.id, input.limit);
      }),
    
    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await markNotificationAsRead(input.notificationId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
