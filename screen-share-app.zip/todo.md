# DocBox Remote - TODO List

## Database & Schema
- [x] Konfiguracija MySQL baze sa Drizzle ORM
- [x] Kreiraj tabele: users, contacts, messages, files, connections, notifications
- [x] Migracije i push baze podataka

## Autentifikacija
- [x] OAuth integracija (Google, GitHub) - vec ugradeno u template
- [x] 2FA sistem sa QR kodovima - implementirano u tRPC
- [x] Session management i JWT tokeni - vec ugradeno
- [x] Logout i session invalidation - vec ugradeno

## WebRTC & Real-time Komunikacija
- [ ] WebRTC signaling server (Socket.io)
- [ ] Peer connection management
- [ ] Screen sharing stream handling
- [ ] Video/audio call establishment
- [ ] Connection state management

## Deljenje Datoteka
- [x] File upload sa progress bar-om - tRPC procedure kreirano
- [x] S3 storage integracija - koristi template storage helpers
- [x] File download funkcionalnost - tRPC procedure kreirano
- [x] File metadata u bazi - tabela kreirano
- [ ] Virus scanning (opciono)

## Obaveštenja
- [x] Real-time notifications - tRPC procedure kreirano
- [x] Notification types: connection requests, file shares, messages
- [ ] Push notifications za inactive korisnike
- [x] Notification history u bazi - tabela kreirano

## Frontend UI
- [x] Dark mode sa theme switching - kreirano
- [x] Framer Motion animacije - kreirano u Home.tsx
- [ ] Responsive design (mobile-first) - u toku
- [x] Chat interfejs - kreirano u Home.tsx
- [x] Contact list sa status indicatorima - kreirano
- [ ] File sharing UI
- [ ] Settings panel

## AI Asistent
- [x] LLM integracija u chat - tRPC procedure kreirano
- [ ] Context awareness za screen sharing
- [ ] Troubleshooting pomoc

## Testiranje
- [ ] Unit testovi sa Vitest
- [ ] Integration testovi
- [ ] WebRTC testovi

## Deployment
- [ ] Build optimizacija
- [ ] Environment variables
- [ ] Production deployment
